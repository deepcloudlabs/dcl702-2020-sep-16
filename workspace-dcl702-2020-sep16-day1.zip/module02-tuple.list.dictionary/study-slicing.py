lst1 = [3, 7, 9, 11, 6, 0, 8]

print(lst1[1:5])

lst1[2:4] = [1, 2]
print(lst1)
print(lst1[:5])
print(lst1[3:])
print(lst1[:])
print(lst1[6])
print(lst1[-1])
print(lst1[-4:])
print(lst1[-6:-2])
print(lst1[2:6:2])
print(lst1[::-1])
print(lst1)